package nullbank;

public class ContaBancaria {
	
	private final Integer numero;
	private String nome;
	private Double saldo;

	public ContaBancaria(Integer numero, String nome) {
		this.numero = numero;
		this.nome = nome;
		this.saldo = 0.0;
	}
	
	public Integer getNumero() {
		return numero;
	}

	public Boolean depositar(Double quantia) {
		this.saldo += (quantia > 0) ? quantia : 0;
		return true;
	}

	public Boolean sacar(Double quantia) {
		Boolean podeSacar = (quantia <= saldo);
		this.saldo -= podeSacar ? quantia : 0;
		return podeSacar;
	}

	public Boolean transferir(ContaBancaria outraConta, Double quantia) {
		if (sacar(quantia)) {
			outraConta.depositar(quantia);
			return true;
		}
		return false;
	}

	@Override
	public String toString() {		
		return String.format("Conta %s#%05d tem %.2f de saldo.", nome, numero, saldo);
	}

}