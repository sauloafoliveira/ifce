package nullbank;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NullBank {

	private static Integer id = 1;
	private static Scanner sc;

	private static List<ContaBancaria> contas = new ArrayList<ContaBancaria>();

	static {
		abrirConta("Saulo"); // 1
		abrirConta("Geovana"); // 2
		abrirConta("JM"); // 3
		abrirConta("João Jr"); // 4
		abrirConta("Fabrícia"); // 5
		abrirConta("João Augusto"); // 6
		abrirConta("Gabriel"); // 7
		abrirConta("Gabriel"); // 8
	}

	/**
	 * Método que abre uma conta no nosso NullBank. Basta informar o {@link nome}
	 * que um número sequencial é gerado e associado à conta. Ele retorna um objeto
	 * do tipo conta que pode ser manipulado posteriormente.
	 */
	public static ContaBancaria abrirConta(String nome) {
		ContaBancaria cb = new ContaBancaria(id++, nome); // cria uma conta
		contas.add(cb); // adiciona nas contas do banco
		return cb;
	}

	public static ContaBancaria getContaPorNumero(Integer numero) {
		for (ContaBancaria cb : contas) {
			if (cb.getNumero().equals(numero)) {
				return cb;
			}
		}

		return null;
	}

	static void teste() {
		ContaBancaria c1 = getContaPorNumero(2);
		ContaBancaria c2 = getContaPorNumero(5);
		ContaBancaria c3 = abrirConta("João Victor");

		System.out.println("-----------------");
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);

		c1.depositar(100.00);
		c2.depositar(33.00);
		c3.depositar(78.45);

		System.out.println("-----------------");
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);

		c1.transferir(c2, 12.0);
		c3.transferir(c1, 5.30);

		System.out.println("-----------------");
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
	}

	public static void main(String[] args) {

		sc = new Scanner(System.in);

		while (true) {

			System.out.println("Digite 01 para fazer um depósito");

			String opcao = sc.next();

			if (opcao.equals("x")) {
				break;
			}

			if (opcao.equals("1")) {
				fazerDeposito();

			}

		}

		sc.close();

	}

	private static void fazerDeposito() {
		System.out.println("Digite o num da conta: ");
		Integer numConta = sc.nextInt();

		System.out.println("Digite o valor a ser depositado: ");
		Double quantia = sc.nextDouble();

		ContaBancaria conta = getContaPorNumero(numConta);

		System.out.println("Status antes do depósito.");
		System.out.println(conta);

		conta.depositar(quantia);

		System.out.println("Deposito feito com sucesso.");
		System.out.println("Status depois do depósito.");
		System.out.println(conta);

	}
}