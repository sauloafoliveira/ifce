from django.db import models

from banco.models import ContaBancaria, Chave

# Create your models here.

class Transacao(models.Model):

    origem = models.ForeignKey(ContaBancaria, on_delete=models.DO_NOTHING, related_name='conta_origem')
    destino = models.ForeignKey(ContaBancaria, on_delete=models.DO_NOTHING, related_name='conta_destino')
    chave = models.ForeignKey(Chave, on_delete=models.DO_NOTHING,  related_name='chave_utilizada')
    valor = models.FloatField(default=0, null=False)
    horario = models.TimeField()