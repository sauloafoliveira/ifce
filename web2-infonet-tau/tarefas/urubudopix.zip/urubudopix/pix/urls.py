from django.urls import path
from . import views

urlpatterns = [
    path('chaves/', views.todas_chaves, name='todas-chaves'),
]
