from django.shortcuts import render
from banco.models import Chave
# Create your views here.


def todas_chaves(req):
    chaves = Chave.objects.all()
    return render(req, 'todas-chaves.html', {'chaves': chaves})