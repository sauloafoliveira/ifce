from django.db import models

# Create your models here.


class ContaBancaria(models.Model):

    nome = models.CharField(max_length=256, null=False)
    saldo = models.FloatField(default=0, null=False)


class Chave(models.Model):

    descricao = models.CharField(max_length=256, null=False, unique=True)
    conta = models.ForeignKey(ContaBancaria, on_delete=models.CASCADE)
    cadastro = models.TimeField(auto_now=True)
