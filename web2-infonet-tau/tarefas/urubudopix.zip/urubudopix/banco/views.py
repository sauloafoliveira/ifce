from django.shortcuts import render
from .models import ContaBancaria

# Create your views here.


def estatisticas(req):
    
    todas_as_contas = ContaBancaria.objects.all()
    
    total = sum(conta.saldo for conta in todas_as_contas)
    
    context = {'total': total, 'n_contas': len(todas_as_contas)}
    
    return render(req, 'patrimonio-banco.html', context)
