from django.urls import path

from . import views

urlpatterns = [
    path('balanco', views.estatisticas, name='balanco'),
]
